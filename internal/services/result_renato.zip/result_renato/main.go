package main

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/aws/aws-sdk-go-v2/aws"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/service/s3"
)

func main() {
	// Sample JSON data with arbitrary properties
	sampleJSON := `
		{
			"name": "John Doe",
			"email": "johndoe@example.com",
			"age": 30,
			"city": "New York"
		}
	`

	// Parse the JSON data into a map
	var jsonData map[string]interface{}
	err := json.Unmarshal([]byte(sampleJSON), &jsonData)
	if err != nil {
		fmt.Println("Error parsing JSON:", err)
		return
	}

	// Encode data to JSON
	jsonBytes, err := json.Marshal(jsonData)
	if err != nil {
		fmt.Println("Error marshaling JSON:", err)
		return
	}

	// Generate timestamp-based filename
	timestamp := time.Now().Format("20060102150405") // Format: YYYYMMDDHHMMSS
	filename := timestamp + "-output.json"

	// AWS S3 upload configuration
	bucketName := "conspirago-documents"
	objectKey := "output/" + filename

	// Load AWS configuration
	cfg, err := config.LoadDefaultConfig(context.TODO())
	if err != nil {
		fmt.Println("Error loading AWS config:", err)
		return
	}

	// Create an S3 client
	client := s3.NewFromConfig(cfg)

	// Upload the JSON data to S3
	_, err = client.PutObject(context.TODO(), &s3.PutObjectInput{
		Bucket: aws.String(bucketName),
		Key:    aws.String(objectKey),
		Body:   bytes.NewReader(jsonBytes),
	})
	if err != nil {
		fmt.Println("Error uploading to S3:", err)
		return
	}
	fmt.Println("JSON data uploaded to S3:", objectKey)
}
